//var socket = io();
var socket = io({transports: ['websocket'], upgrade: false});
